# Bicycle activity

# Imports
from bicycle_lib import *

while True:
    # Get pot value
    value = getPot()
    displayValue(value)
    
    sleep(0.2)


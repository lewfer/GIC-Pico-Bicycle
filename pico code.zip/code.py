# Bicycle activity

# Imports
from bicycle_lib import *

min_pot = 1450
mid_pot = 4000
max_pot = 6553

while True:
    if checkBike():
        # Get pot and candence values
        value = getPot()
        cadence = getCadence()

        # Convert cadence value to speed and pot value to braking
        speed = map(cadence, 0, 100, 0, 100)
        braking = map(value, mid_pot, min_pot, 0, 100)
        print(speed, braking)
        
        # Apply speed or braking
        if braking>0:
            brake(braking)
        elif speed>=0:
            accelerate(speed)

        actualSpeed = getActualSpeed()
        displayValue(actualSpeed)
      
        
#     # Get pot value
#     value = getPot()
#     
#     # Convert pot value to a speed or braking
#     speed = map(value, mid_pot, max_pot, 0, 100)
#     braking = map(value, mid_pot, min_pot, 0, 100)
#     print(speed, braking)
#     
#     # Apply speed or braking
#     if speed>0:
#         accelerate(speed)
#     elif braking>0:
#         brake(braking)
#     
#     displayValue(speed)
#     sleep(0.2)



# wait = 0.2
# use_throttle = False
# 
# 
#     
# 
# 
# requestedSpeed = 0
# val = 0
# while True:
#     if checkBike():
# 
#         cadence = getCadence()
#         
#         #print("Cadence", cadence)
#         throttle = getThrottle()
#         
#         #print("Throttle", throttle, "Cadence", cadence)
#         
#         if use_throttle:
#             # Throttle drive
#             if throttle>0:
#                 drive(throttle)
#             else:
#                 brake(throttle)
#         else:
#             # Pedal drive
#             requestedSpeed = map(cadence, 0, 100, 0, 100)
#             print(cadence, requestedSpeed)
#             
#             if throttle<0:
#                 brake(throttle)
#             else:
#                 accelerate(requestedSpeed)
#             
#         # Show speed
#         displayValue(actualSpeed)
